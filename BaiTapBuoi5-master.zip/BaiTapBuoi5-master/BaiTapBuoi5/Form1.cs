﻿using System;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Windows.Forms;

namespace BaiTapBuoi5
{
    public partial class Form1 : Form
    {
        private string currentFile = ""; 

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            foreach (FontFamily font in new InstalledFontCollection().Families)
            {
                cmbFonts.Items.Add(font.Name);
            }
            cmbFonts.SelectedItem = "Tahoma"; 

            int[] sizes = { 8, 9, 10, 11, 12, 14, 16, 18, 20, 22, 24, 26, 28, 36, 48, 72 };
            foreach (int size in sizes)
            {
                cmbSize.Items.Add(size);
            }
            cmbSize.SelectedItem = 14; 

            richText.Font = new Font("Tahoma", 14);
        }

        private void mnuNew_Click(object sender, EventArgs e)
        {
            btnNew_Click(sender, e); 
        }

        private void mnuOpen_Click(object sender, EventArgs e)
        {
            btnOpen_Click(sender, e);
        }

        private void mnuSave_Click(object sender, EventArgs e)
        {
            btnSave_Click(sender, e);
        }

        private void mnuExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void mnuFont_Click(object sender, EventArgs e)
        {
            FontDialog fontDlg = new FontDialog();
            fontDlg.ShowColor = true;
            fontDlg.ShowApply = true;
            fontDlg.ShowEffects = true;
            fontDlg.ShowHelp = true;

            if (fontDlg.ShowDialog() != DialogResult.Cancel)
            {
                richText.ForeColor = fontDlg.Color;
                richText.Font = fontDlg.Font;
            }
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            richText.Clear();
            currentFile = "";
            cmbFonts.SelectedItem = "Tahoma";
            cmbSize.SelectedItem = 14;
            richText.Font = new Font("Tahoma", 14);
        }

        private void btnOpen_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Rich Text Format|*.rtf|Text Files|*.txt";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                currentFile = ofd.FileName;
                if (Path.GetExtension(currentFile).ToLower() == ".rtf")
                    richText.LoadFile(currentFile, RichTextBoxStreamType.RichText);
                else
                    richText.LoadFile(currentFile, RichTextBoxStreamType.PlainText);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(currentFile))
            {
                SaveFileDialog sfd = new SaveFileDialog();
                sfd.Filter = "Rich Text Format|*.rtf";

                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    currentFile = sfd.FileName;
                    richText.SaveFile(currentFile, RichTextBoxStreamType.RichText);
                }
            }
            else
            {
                richText.SaveFile(currentFile, RichTextBoxStreamType.RichText);
                MessageBox.Show("Lưu thành công!", "Thông báo");
            }
        }

        private void btnBold_Click(object sender, EventArgs e)
        {
            ChangeFontStyle(FontStyle.Bold);
        }

        private void btnItalic_Click(object sender, EventArgs e)
        {
            ChangeFontStyle(FontStyle.Italic);
        }

        private void btnUnderline_Click(object sender, EventArgs e)
        {
            ChangeFontStyle(FontStyle.Underline);
        }

        private void ChangeFontStyle(FontStyle style)
        {
            if (richText.SelectionFont != null)
            {
                FontStyle newStyle = richText.SelectionFont.Style ^ style;
                richText.SelectionFont = new Font(richText.SelectionFont, newStyle);
            }
        }

        private void cmbFonts_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbFonts.SelectedItem != null && cmbSize.SelectedItem != null)
            {
                richText.SelectionFont = new Font(cmbFonts.SelectedItem.ToString(),
                    float.Parse(cmbSize.SelectedItem.ToString()));
            }
        }

        private void cmbSize_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cmbFonts.SelectedItem != null && cmbSize.SelectedItem != null)
            {
                richText.SelectionFont = new Font(cmbFonts.SelectedItem.ToString(),
                    float.Parse(cmbSize.SelectedItem.ToString()));
            }
        }

        private void richText_TextChanged(object sender, EventArgs e)
        {
            string[] words = richText.Text.Split(new char[] { ' ', '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
            statusLabel.Text = $"Tổng số từ: {words.Length}";
        }
    }
}
